import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    // bind every interface so the server is reachable from the device's WebView
    // on 127.0.0.1 and from another machine on the phone's LAN address
    host: '0.0.0.0',

    port: 5173,
    strictPort: true,

    hmr: {
      // deliberately no `host`: the HMR endpoint is baked into the client that
      // gets served, so pinning it sends a laptop's browser to its own
      // 127.0.0.1. Letting Vite infer it from window.location makes HMR work
      // from the on-device WebView and over the LAN alike.
      protocol: 'ws',
      port: 5173,
    },

    watch: {
      usePolling: true,
      interval: 300,
    },
  },
})
